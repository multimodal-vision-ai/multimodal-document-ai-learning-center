"""Download original assets and contemporaneous source evidence; resumable HTTP ranges."""
from pathlib import Path
import concurrent.futures as cf
import hashlib, json, time, requests

ROOT = Path(__file__).resolve().parent
SOURCES = [
 dict(id='A', title='Udacity project_video', url='https://raw.githubusercontent.com/udacity/CarND-Vehicle-Detection/master/project_video.mp4', page='https://github.com/udacity/CarND-Vehicle-Detection', filename='A.mp4', author='Udacity (repository copyright holder); individual camera operator not identified', license='MIT (repository-level; no separate video attribution found)', license_url='https://github.com/udacity/CarND-Vehicle-Detection/blob/master/LICENSE'),
 dict(id='B', title='City Driving 4K: Kraków Poland 2024', url='https://upload.wikimedia.org/wikipedia/commons/9/98/City_Driving_4K-_Krak%C3%B3w_Poland_2024.webm', page='https://commons.wikimedia.org/wiki/File:City_Driving_4K-_Krak%C3%B3w_Poland_2024.webm', filename='B.webm', author='Relaxing Roads 4K', license='CC BY 3.0', license_url='https://creativecommons.org/licenses/by/3.0/'),
 dict(id='C', title='On the Road: Foggy Ljubljana', url='https://upload.wikimedia.org/wikipedia/commons/3/3d/On_the_Road-_Foggy_Ljubljana.webm', page='https://commons.wikimedia.org/wiki/File:On_the_Road-_Foggy_Ljubljana.webm', filename='C.webm', author='Renato Lozinšek', license='CC BY 3.0', license_url='https://creativecommons.org/licenses/by/3.0/'),
]
HEADERS={'User-Agent':'MVAI-E04-MaterialReview/1.0 (educational material verification)'}

def fetch(url, path):
    path=Path(path)
    for attempt in range(5):
        try:
            offset=path.stat().st_size if path.exists() else 0
            headers={**HEADERS, **({'Range':f'bytes={offset}-'} if offset else {})}
            with requests.get(url,headers=headers,stream=True,timeout=(30,120)) as r:
                if r.status_code==416: return
                r.raise_for_status()
                mode='ab' if offset and r.status_code==206 else 'wb'
                with path.open(mode) as f:
                    for chunk in r.iter_content(2**20): f.write(chunk)
            return
        except Exception as e:
            print(f'{path.name}: attempt {attempt+1}: {e}',flush=True)
            time.sleep(2+attempt*3)
    raise RuntimeError(str(path))

def acquire(s):
    evidence=ROOT/'evidence'; evidence.mkdir(exist_ok=True)
    fetch(s['page'],evidence/f"{s['id']}-source.html")
    if s['id']=='A':
        fetch('https://raw.githubusercontent.com/udacity/CarND-Vehicle-Detection/master/LICENSE',evidence/'A-LICENSE.txt')
        # GitHub anonymous commit API is rate limited; retain repository source and LICENSE.
    else:
        title=s['page'].split('/wiki/')[1]
        fetch('https://commons.wikimedia.org/w/api.php?action=query&format=json&prop=imageinfo&iiprop=url%7Csize%7Csha1%7Cextmetadata&titles='+title,evidence/f"{s['id']}-imageinfo.json")
    path=ROOT/'originals'/s['filename']
    print(f'Downloading {s["id"]}: {s["url"]}',flush=True)
    fetch(s['url'],path)
    s['bytes']=path.stat().st_size
    h=hashlib.sha256(); sha1=hashlib.sha1()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(8*2**20),b''): h.update(b); sha1.update(b)
    s.update(sha256=h.hexdigest(),sha1=sha1.hexdigest(),downloaded_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
    (evidence/f"{s['id']}-download.json").write_text(json.dumps(s,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'COMPLETE {s["id"]}: {s["bytes"]:,} bytes sha256={s["sha256"]}',flush=True)
    return s

if __name__=='__main__':
    # User revised scope: short clips only. Never download complete source videos.
    evidence=ROOT/'evidence'; evidence.mkdir(exist_ok=True)
    for s in SOURCES: fetch(s['page'],evidence/f"{s['id']}-source.html")
    fetch('https://raw.githubusercontent.com/udacity/CarND-Vehicle-Detection/master/LICENSE',evidence/'A-LICENSE.txt')
    (evidence/'sources.json').write_text(json.dumps(SOURCES,ensure_ascii=False,indent=2),encoding='utf-8')
