from prepare import *
from PIL import ImageDraw
from acquire import SOURCES
DIST=ROOT/'dist'
for d in ['videos','frames','comparisons','data','licenses']: (DIST/d).mkdir(parents=True,exist_ok=True)
clips=[('A','A.mp4',30),('B','B.webm',60),('C','C.webm',175)]
records=[]
for s,name,start in clips:
    dest=DIST/'videos'/f'{s}.mp4'
    # Stream only the selected source time range; do not retain full source files.
    source=next(x['url'] for x in SOURCES if x['id']==s)
    if not dest.exists():
        subprocess.run([FF,'-y','-ss',str(start),'-i',source,'-t','12','-vf','scale=1280:720','-r','25','-c:v','libx264','-preset','fast','-crf','23','-pix_fmt','yuv420p','-an','-movflags','+faststart',str(dest)],check=True,stdout=subprocess.DEVNULL,stderr=(ROOT/'evidence'/f'{s}-encode.log').open('w'))
    md=metadata(dest); assert md['frames']==300 and md['width']==1280 and md['height']==720
    records.append(dict(id=s,start=start,duration=12,metadata=md,bytes=dest.stat().st_size,sha256=__import__('hashlib').sha256(dest.read_bytes()).hexdigest(),changes='12-second excerpt; scaled to 1280x720; H.264/yuv420p; 25fps; audio removed; detection overlays on derived stills only',source_file=name))
    for j,t in enumerate([2,6,10],1):
        im=frame(dest,t); cv2.imwrite(str(DIST/'frames'/f'{s}{j}.jpg'),im,[cv2.IMWRITE_JPEG_QUALITY,94])
    print(s,md,dest.stat().st_size,flush=True)
(DIST/'data'/'clips.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
sheet=Image.new('RGB',(960,606),'#18202c'); draw=ImageDraw.Draw(sheet)
for i,s in enumerate('ABC'):
    for j in range(3):
        im=Image.open(DIST/'frames'/f'{s}{j+1}.jpg'); im.thumbnail((320,180));sheet.paste(im,(j*320,i*202));draw.text((j*320+8,i*202+181),f'{s}{j+1}: original {clips[i][2]+[2,6,10][j]}s',fill='white')
sheet.save(DIST/'comparisons'/'nine-frames.jpg')
