"""Actual YOLO26 forwards; official postprocessing over the full parameter grid.
Reuse each raw forward across conf/IoU settings (neither changes the network).
"""
from prepare import *
import torch, ultralytics, time, itertools, csv, hashlib, platform
from ultralytics import YOLO
torch.set_num_threads(4)
D=ROOT/'dist'; rows=[]; outputs=[]; forward_log=[]
ROAD={0,1,2,3,5,7,9,11}
def boxes(r):
    return [dict(cls=int(c),name=r.names[int(c)],conf=round(float(v),7),xyxy=[round(float(x),3) for x in xy]) for xy,c,v in zip(r.boxes.xyxy.tolist(),r.boxes.cls.tolist(),r.boxes.conf.tolist())]

for modelname,mode in itertools.product(['yolo26n','yolo26s'],['traditional_nms','nms_free']):
    model=YOLO(str(ROOT/'models'/f'{modelname}.pt'))
    model.predict(str(D/'frames'/'A1.jpg'),imgsz=320,nms=(mode=='traditional_nms'),conf=.05,rect=False,device='cpu',verbose=False,save=False)
    p=model.predictor
    assert bool(p.model.end2end)==(mode=='nms_free')
    for size in [320,640,960]:
        p.imgsz=[size,size];p.args.imgsz=size
        for path in sorted((D/'frames').glob('*.jpg')):
            im=cv2.imread(str(path)); p.batch=([str(path)],[im],[''])
            t=time.perf_counter()
            with torch.inference_mode():
                tensor=p.preprocess([im]); raw=p.inference(tensor)
            ms=(time.perf_counter()-t)*1000
            forward_log.append(dict(model=modelname,mode=mode,frame=path.stem,imgsz=size,shape=list(tensor.shape),forward_preprocess_ms=ms))
            for conf,iou in itertools.product([.05,.25,.5,.8],[.3,.5,.7]):
                p.args.conf=conf;p.args.iou=iou
                with torch.inference_mode(): r=p.postprocess(raw,tensor,[im])[0]
                b=boxes(r)
                rec=dict(model=modelname,mode=mode,frame=path.stem,imgsz=size,conf=conf,iou=iou,boxes=b)
                outputs.append(rec)
                counts={name:sum(x['name']==name for x in b) for name in sorted({x['name'] for x in b})}
                rows.append({k:v for k,v in rec.items() if k!='boxes'}|dict(detections=len(b),road_detections=sum(x['cls'] in ROAD for x in b),class_counts=json.dumps(counts),forward_preprocess_ms=round(ms,3)))
            print(modelname,mode,size,path.stem,'forward_ms',round(ms),flush=True)
    del model,p
(D/'data'/'detections.json').write_text(json.dumps(outputs,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
with (D/'data'/'parameter-statistics.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
(D/'data'/'forward-log.json').write_text(json.dumps(forward_log,indent=2),encoding='utf-8')
env=dict(python=platform.python_version(),platform=platform.platform(),torch=torch.__version__,ultralytics=ultralytics.__version__,device='cpu',threads=4,seed=0,weights={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'models').glob('*.pt')},protocol='108 raw image forwards + 4 warmup calls; 1296 official postprocess results. Full 648-setting traditional NMS grid plus 648 NMS-free controls. Each raw forward reused for 12 conf/IoU combinations; no interpolation or fabricated predictions. Times are forward+preprocess, not end-to-end FPS. nms=True selects one-to-many head; nms=False selects end-to-end one-to-one head in ultralytics 8.4.219. All 80 COCO classes; class-aware NMS; max_det=300; rect=False; no ground truth, no mAP/precision/recall claims.')
(D/'data'/'environment.json').write_text(json.dumps(env,ensure_ascii=False,indent=2),encoding='utf-8')
lookup={(x['model'],x['mode'],x['frame'],x['imgsz'],x['conf'],x['iou']):x for x in outputs}
def panel(rec,label):
    im=cv2.imread(str(D/'frames'/f'{rec["frame"]}.jpg'))
    for b in rec['boxes']:
        x,y,x2,y2=map(round,b['xyxy']);col=(40,220,90) if b['cls'] in ROAD else (60,140,255)
        cv2.rectangle(im,(x,y),(x2,y2),col,2);cv2.putText(im,f'{b["name"]} {b["conf"]:.2f}',(x,max(18,y-4)),cv2.FONT_HERSHEY_SIMPLEX,.55,col,2)
    im=cv2.resize(im,(640,360));cv2.rectangle(im,(0,0),(640,28),(18,25,35),-1);cv2.putText(im,label,(8,20),cv2.FONT_HERSHEY_SIMPLEX,.5,(255,255,255),1)
    return im
for f in [f'{s}{i}' for s in 'ABC' for i in [1,2,3]]:
    settings={
      'confidence': [('yolo26n','traditional_nms',f,640,c,.5) for c in [.05,.25,.5,.8]],
      'iou': [('yolo26n','traditional_nms',f,640,.05,i) for i in [.3,.5,.7]],
      'size': [('yolo26n','traditional_nms',f,z,.25,.5) for z in [320,640,960]],
      'models': [(m,mode,f,640,.25,.5) for m,mode in itertools.product(['yolo26n','yolo26s'],['traditional_nms','nms_free'])]}
    for kind,keys in settings.items():
        tiles=[panel(lookup[k],f'{k[0]} {k[1]} size={k[3]} conf={k[4]} iou={k[5]}') for k in keys]
        if len(tiles)==3: tiles.append(__import__('numpy').zeros_like(tiles[0]))
        plate=__import__('numpy').vstack([__import__('numpy').hstack(tiles[:2]),__import__('numpy').hstack(tiles[2:])])
        cv2.imwrite(str(D/'comparisons'/f'{f}-{kind}.jpg'),plate,[cv2.IMWRITE_JPEG_QUALITY,87])
print('FINISHED',len(outputs),'results',len(forward_log),'forwards',flush=True)
