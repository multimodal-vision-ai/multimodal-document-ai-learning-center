from prepare import *
import hashlib, re, torch
from ultralytics import YOLO
torch.set_num_threads(4)
D=ROOT/'dist'; data=json.loads((D/'data'/'detections.json').read_text())
assert len(data)==1296
keys=[(r['model'],r['mode'],r['frame'],r['imgsz'],r['conf'],r['iou']) for r in data]
assert len(set(keys))==1296
assert len(list((D/'frames').glob('*.jpg')))==9
assert len(list((D/'comparisons').glob('*.jpg')))==37
log={'grid_records':len(data),'unique_parameter_keys':len(set(keys)),'original_frames':9,'comparison_plates':36,'videos':[],'independent_predict_checks':[],'browser_qa':'2026-11-26: IAB localhost page; all 3 videos duration=12, readyState=4, playback currentTime>0, no media error; C1 n/640/conf .25=1 and conf .5=0; NMS-free disables IoU; mobile-width layout checked.'}
for p in sorted((D/'videos').glob('*.mp4')):
    md=metadata(p); assert md['frames']==300 and md['fps']==25 and md['width']==1280
    cap=cv2.VideoCapture(str(p)); count=0
    while True:
        ok,im=cap.read()
        if not ok:break
        count+=1
    cap.release();assert count==300
    result=subprocess.run([FF,'-i',str(p),'-f','null','-'],capture_output=True,text=True)
    assert result.returncode==0 and 'h264' in result.stderr and 'yuv420p' in result.stderr
    b=p.read_bytes();assert b.find(b'moov')<b.find(b'mdat')
    log['videos'].append(dict(file=p.name,decoded_frames=count,codec='H.264',pixel_format='yuv420p',faststart=True,bytes=len(b)))
for m,mode,f,z,c,i in [('yolo26n','traditional_nms','C1',640,.5,.3),('yolo26n','traditional_nms','B1',960,.05,.7),('yolo26s','traditional_nms','B3',320,.25,.5),('yolo26s','nms_free','C3',640,.25,.7)]:
    model=YOLO(str(ROOT/'models'/f'{m}.pt'))
    r=model.predict(str(D/'frames'/f'{f}.jpg'),nms=mode=='traditional_nms',imgsz=z,conf=c,iou=i,rect=False,device='cpu',verbose=False)[0]
    expected=data[keys.index((m,mode,f,z,c,i))]['boxes']
    actual=[dict(cls=int(cl),conf=float(co),xyxy=xy) for cl,co,xy in zip(r.boxes.cls.tolist(),r.boxes.conf.tolist(),r.boxes.xyxy.tolist())]
    assert len(expected)==len(actual)
    for a,b in zip(actual,expected):
        assert a['cls']==b['cls'] and abs(a['conf']-b['conf'])<1e-5 and max(abs(x-y) for x,y in zip(a['xyxy'],b['xyxy']))<.01
    log['independent_predict_checks'].append(dict(model=m,mode=mode,frame=f,imgsz=z,conf=c,iou=i,matched=True))
for p in D.glob('*.html'):
    for link in re.findall(r'(?:href|src)="([^"#]+)"',p.read_text(encoding='utf-8')):
        if not link.startswith(('https:','http:')) and link not in ['data/validation.json','data/file-checksums.json']: assert (p.parent/link).exists(),link
(D/'data'/'validation.json').write_text(json.dumps(log,ensure_ascii=False,indent=2),encoding='utf-8')
checksums={str(p.relative_to(D)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in D.rglob('*') if p.is_file() and p.name!='file-checksums.json'}
(D/'data'/'file-checksums.json').write_text(json.dumps(checksums,indent=2),encoding='utf-8')
print(json.dumps(log,ensure_ascii=False,indent=2),flush=True)
