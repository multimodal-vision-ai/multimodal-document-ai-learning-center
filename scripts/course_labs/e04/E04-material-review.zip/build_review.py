from pathlib import Path
import json, shutil, csv, hashlib
from acquire import SOURCES
R=Path(__file__).resolve().parent;D=R/'dist'
data=json.loads((D/'data'/'detections.json').read_text())
def select(**kw): return [r for r in data if all(r[k]==v for k,v in kw.items())]
def total(**kw):return sum(len(x['boxes']) for x in select(**kw))
base=dict(model='yolo26n',mode='traditional_nms',imgsz=640,iou=.5,conf=.25)
summary=dict(confidence=[dict(value=c,count=total(**(base|dict(conf=c)))) for c in [.05,.25,.5,.8]],size=[dict(value=z,count=total(**(base|dict(imgsz=z)))) for z in [320,640,960]],models=[dict(value=m,count=total(**(base|dict(model=m)))) for m in ['yolo26n','yolo26s']])
lookup={(r['model'],r['mode'],r['frame'],r['imgsz'],r['conf'],r['iou']):r['boxes'] for r in data}
summary['iou_changed']=sum(lookup[(m,'traditional_nms',f,z,c,.3)]!=lookup[(m,'traditional_nms',f,z,c,.7)] for m in ['yolo26n','yolo26s'] for f in [f'{s}{j}' for s in 'ABC' for j in [1,2,3]] for z in [320,640,960] for c in [.05,.25,.5,.8])
assert all(lookup[(m,'nms_free',f,z,c,.3)]==lookup[(m,'nms_free',f,z,c,.7)] for m in ['yolo26n','yolo26s'] for f in [f'{s}{j}' for s in 'ABC' for j in [1,2,3]] for z in [320,640,960] for c in [.05,.25,.5,.8])
(D/'data'/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
clips=json.loads((D/'data'/'clips.json').read_text())
for s,c in zip(SOURCES,clips):
    s.update(clip_start=c['start'],clip_end=c['start']+12,changes=c['changes'],clip_sha256=c['sha256'],individual_camera_operator_verified=s['id']!='A')
    s['video_authorization_note'] = (
        '2026-11-26：用户确认 A 的视频专项授权可以用于 E04。公开来源列出 Udacity 仓库 MIT 许可，未单列摄影者署名。'
        if s['id']=='A' else 'Wikimedia Commons 文件页列出作者及 CC BY 3.0 许可。'
    )
    for suffix in ['source.html','imageinfo.json','LICENSE.txt']:
        p=R/'evidence'/f'{s["id"]}-{suffix}'
        if p.exists(): shutil.copyfile(p,D/'licenses'/p.name)
(D/'data'/'sources.json').write_text(json.dumps(SOURCES,ensure_ascii=False,indent=2),encoding='utf-8')
with (D/'data'/'sources.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(SOURCES[0]));w.writeheader();w.writerows(SOURCES)
failures=[dict(frame='C1',type='高阈值漏检',evidence='YOLO26n / 640 / NMS IoU 0.5：前方车辆 conf=0.2917005；conf=0.25 保留，0.5 与 0.8 消失。',image='C1-confidence.jpg'),dict(frame='C3',type='车内物体误检',evidence='YOLO26n / 640 / conf=0.25 / NMS IoU 0.5：左上车内支架被标为 person 0.4821418；导航屏幕被标为 tv 0.3513848。画面中这两个框不代表道路目标。',image='C3-models.jpg'),dict(frame='B3',type='类别混淆候选',evidence='YOLO26n / 640 / conf=0.25 / NMS IoU 0.5：右侧行人脚下附近输出 skateboard 0.4567129。需要教师放大原图核实；未将此候选计作已确认误检。',image='B3-models.jpg')]
(D/'data'/'failure-cases.json').write_text(json.dumps(failures,ensure_ascii=False,indent=2),encoding='utf-8')
(D/'REVIEW.md').write_text('''# E04 教师素材审核

2026-11-26，用户确认 A 的视频专项授权可以用于 E04，并同意推进下一步。以下为素材筛选阶段的证据。
按用户最新要求仅保留短片，完整原片及下载分块已清理。三段均为驾驶员前向视角、12 秒、1280×720、25fps、H.264/yuv420p、无音频、faststart；时间为来源播放器秒数，C 原视频自带时间戳与页面发表日期不一致，保留原样，不据此推断拍摄日期。

| 素材 | 来源范围 | 作用 | 来源署名与许可 |
|---|---|---|---|
| A | 30–42秒 | 晴天高速车辆 | A 的视频专项授权经用户确认。公开来源为 Udacity 仓库 MIT（Copyright 2017–2018 Udacity, Inc.），未单列摄影者署名。 |
| B | 60–72秒 | 城市车辆、行人和小目标 | Relaxing Roads 4K；CC BY 3.0；Commons 有历史许可复核，YouTube 后续修改许可不撤销既有许可 |
| C | 175–187秒 | 夜雾、眩光、远距车辆 | Renato Lozinšek；CC BY 3.0 |

来源、许可链接、处理说明和短片 SHA256 见 data/sources.json；许可网页和 Commons API 证据见 licenses/。每次再分发 B/C 的片段、帧或检测图应保留作者、来源、CC BY 3.0 链接及改动说明。A 保留 MIT 全文。

## 实验边界

从每段片段第2、6、10秒提取3帧，共9帧。使用官方 yolo26n.pt / yolo26s.pt COCO预训练模型；传统 NMS 648 组：2模型×9帧×4置信度×3IoU×3尺寸，另有648组免NMS对照。108次真实网络前向输出复用到12组官方后处理参数；这不是1296次独立网络前向。没有插值或伪造输出。全部80类均保留，road_detections仅为COCO道路相关类别计数。

Ultralytics 8.4.219 中 nms=True 选择 one-to-many 分支并执行传统 class-aware NMS；nms=False 选择 one-to-one 免NMS分支。同一模型的两个分支不是只改变后处理的等价基线。免NMS分支 IoU 0.3/0.5/0.7 的所有结果相同；传统 NMS 有53/216组在0.3与0.7之间发生输出变化。

YOLO26n / 640 / IoU 0.5，九帧总检测数随 conf=0.05/0.25/0.5/0.8 为84/34/22/12；conf=0.25时320/640/960为24/34/43；640时n/s为34/43。数量多不能推导更准确。已人工查看C1高阈值车辆消失和C3车内物体误检；B3 skateboard 仅为待核实候选。

本实验不含人工逐框真值，不报告mAP、准确率、召回率或整段视频稳定性。仅9张代表帧参与参数网格；视频用于教师观看原始动态场景。计时是CPU预处理加前向，不是视频FPS。

## 复现与验收

源码 infer.py、模型SHA256和环境版本可追溯。先运行 clips.py（网络按时间读取，仅保存12秒短片），再运行 infer.py、build_review.py、validate.py；已有短片不会重下载。源站限流时保留现有短片，勿恢复全片下载。requirements.lock.txt 固定本次依赖。

教师可在页面查看视角、连续性、许可、教学价值和失败案例，并导出本地验收意见。A 的授权确认已记录在来源清单中。
''',encoding='utf-8')
for p in [R/'infer.py',R/'clips.py',R/'prepare.py',R/'acquire.py']:
    (D/'reproduce').mkdir(exist_ok=True);shutil.copyfile(p,D/'reproduce'/p.name)
print(summary)
