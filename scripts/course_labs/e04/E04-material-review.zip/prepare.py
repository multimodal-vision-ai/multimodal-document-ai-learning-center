from pathlib import Path
import os, json, subprocess, sys
ROOT=Path(__file__).resolve().parent
os.environ['YOLO_CONFIG_DIR']=str(ROOT/'.config')
os.environ['MPLCONFIGDIR']=str(ROOT/'.config'/'matplotlib')
os.environ['YOLO_OFFLINE']='true'
os.environ['YOLO_AUTOINSTALL']='false'
import cv2
from PIL import Image, ImageDraw
import imageio_ffmpeg
FF=imageio_ffmpeg.get_ffmpeg_exe()

def metadata(p):
    c=cv2.VideoCapture(str(p)); fps=c.get(cv2.CAP_PROP_FPS); n=c.get(cv2.CAP_PROP_FRAME_COUNT)
    d=dict(width=int(c.get(3)),height=int(c.get(4)),fps=fps,frames=int(n),duration=n/fps); c.release(); return d

def frame(p,t):
    c=cv2.VideoCapture(str(p)); c.set(cv2.CAP_PROP_POS_MSEC,t*1000); ok,im=c.read(); c.release()
    if not ok: raise RuntimeError(f'Cannot decode {p}@{t}')
    return im

def contact(s):
    p=ROOT/'originals'/('A.mp4' if s=='A' else s+'.webm')
    md=metadata(p); (ROOT/'evidence'/f'{s}-video.json').write_text(json.dumps(md,indent=2))
    times=([3,10,20,30,40,45] if s=='A' else [30,60,120,180,300,600,900,1200,1500])
    sheet=Image.new('RGB',(960,202*(len(times)//3+bool(len(times)%3))), '#18202c'); dr=ImageDraw.Draw(sheet)
    for i,t in enumerate(times):
        im=Image.fromarray(cv2.cvtColor(frame(p,t),cv2.COLOR_BGR2RGB)); im.thumbnail((320,180)); x=i%3*320;y=i//3*202
        sheet.paste(im,(x,y));dr.text((x+8,y+181),f'{s}  {t}s',fill='white')
    sheet.save(ROOT/'evidence'/f'{s}-contact.jpg')
    print(s,md,flush=True)

if __name__=='__main__':
    if sys.argv[1]=='models':
        from acquire import fetch
        (ROOT/'models').mkdir(exist_ok=True)
        for m in ['yolo26n','yolo26s']:
            fetch(f'https://github.com/ultralytics/assets/releases/download/v8.4.0/{m}.pt', ROOT/'models'/f'{m}.pt')
            print(m,'downloaded',flush=True)
    else:
        for s in sys.argv[1:]: contact(s)
