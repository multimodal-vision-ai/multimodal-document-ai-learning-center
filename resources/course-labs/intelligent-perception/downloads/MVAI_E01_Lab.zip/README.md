E01/E02 探索式教学素材

将完整 ZIP 解压。使用 Python+OpenCV+NumPy+Matplotlib 的 Jupyter/VS Code 打开 Notebook。Kaggle 请将 ZIP 解压后添加为 Dataset。
视频为可选素材，不需要下载完整五段源视频。网页版 JavaScript 计算与 OpenCV 不保证逐像素一致。
