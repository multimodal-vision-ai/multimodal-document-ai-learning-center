# E03 复杂道路车道检测

ZIP 同时包含 V1.0 Baseline 与 V1.1 Improved 两份独立 Notebook。建议先运行 V1.0 建立对照，再运行 V1.1 观察改进；按顺序执行各 Cell。

Kaggle: 上传解压后的整个目录为 Dataset，并把 Notebook 同时放入工作区。

推荐运行 V1.1 Notebook；V1.0 保留为原始二次曲线 Baseline。依赖：opencv-python、numpy、matplotlib、IPython、nbclient（仅站点构建）。
视频采用 12 FPS、640×360 的真实 Udacity 原视频切片，无需下载完整数据集。浏览器交互是教学近似实现，不保证逐像素等于 OpenCV。
