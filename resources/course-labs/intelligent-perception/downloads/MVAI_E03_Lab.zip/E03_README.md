# E03 复杂道路车道检测

将 ZIP 解压后使用 Jupyter/VS Code 打开唯一标准 Notebook，按顺序运行 Cell。Kaggle: 上传解压后的整个目录为 Dataset，并把 Notebook 同时放入工作区。依赖：opencv-python、numpy、matplotlib、IPython、nbclient（仅站点构建）。
视频采用 12 FPS、640×360 的真实 Udacity 原视频切片，无需下载完整数据集。浏览器交互是教学近似实现，不保证逐像素等于 OpenCV。
